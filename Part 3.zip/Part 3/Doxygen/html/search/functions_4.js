var searchData=
[
  ['removeappointment_155',['removeAppointment',['../class_schedule.html#ac0cc730d87aedb39a7ed1e6ea9dc4ba7',1,'Schedule']]],
  ['removeavailableslot_156',['removeAvailableSlot',['../class_schedule.html#a1487df95f4fb4f5324c76f20b7a444b4',1,'Schedule']]],
  ['removetest_157',['removeTest',['../class_visit.html#ac70f594c6601025a46ccf2766b216820',1,'Visit']]],
  ['removetestresult_158',['removeTestResult',['../class_visit.html#a61734c2c951b6232aa21716822ceab3d',1,'Visit']]],
  ['report_159',['Report',['../class_report.html#ae3150817fcf4ebf814358baf5bd72e8f',1,'Report::Report()'],['../class_report.html#ada49c49f94c43aee7dccf146bb396480',1,'Report::Report(DateTime dateGenerated, string reportData)']]]
];
