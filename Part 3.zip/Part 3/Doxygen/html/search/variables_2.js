var searchData=
[
  ['minute_194',['minute',['../struct_date_time.html#a968aece0ae2649712e90d93d4613e08f',1,'DateTime']]],
  ['month_195',['month',['../struct_date.html#a533843e07c6ac8d19fee9b16f5336ba2',1,'Date']]]
];
