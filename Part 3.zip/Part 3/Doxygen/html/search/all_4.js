var searchData=
[
  ['invoice_43',['Invoice',['../class_invoice.html',1,'Invoice'],['../class_invoice.html#a25d6ad261479340ac3775e21f03eef90',1,'Invoice::Invoice()'],['../class_invoice.html#a183dc926da1f27e56edec1d05ef84db6',1,'Invoice::Invoice(Visit visit, int cost, DateTime dateCreated, bool paid)']]],
  ['ispaid_44',['isPaid',['../class_invoice.html#afb188d5afeb00d8d4398cc1ba0db6836',1,'Invoice']]]
];
