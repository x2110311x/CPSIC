var indexSectionsWithContent =
{
  0: "adghimprstvy~",
  1: "adiprstv",
  2: "aptv",
  3: "agiprstv~",
  4: "dhmsy"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables"
};

