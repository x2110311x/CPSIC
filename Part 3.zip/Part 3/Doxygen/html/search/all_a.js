var searchData=
[
  ['visit_87',['Visit',['../class_visit.html',1,'Visit'],['../class_visit.html#a89fd92eb1260be0ccff609362cb847d2',1,'Visit::Visit()'],['../class_visit.html#a3af94603b0079a9c375b3a05b09ee577',1,'Visit::Visit(string type, Patient patient, Personnel personnel, TestResult testResult, Test test, AppointmentSlot dateTime)']]],
  ['visit_2eh_88',['visit.h',['../visit_8h.html',1,'']]]
];
