/**
 * Report.cpp
 * 
 * Declaration of Report
 */

#include "Report.h"

using namespace std;

/** 
 * Retrieve the date the report was generated
 */
DateTime getDateGenerated(){
    DateTime returnvar;
    return returnvar;
}

/**
 * Retrieve the data of the report
 */
string getReportData(){
    string returnvar;
    return;
}

/** 
 * set the date of the report
 */
void setDateGenerated(DateTime date){
    return;
}

/**
 * set the data of the report
 */
void setReportData(string data){
    return;
}