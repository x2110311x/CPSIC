/**
 * PersonnelSchedule.cpp
 * 
 * Declaration of PersonnelSchedule
 */

#include "PersonnelSchedule.h"
using namespace std;

/**
 * Get the Personnel object
 */
Personnel getPersonnel(){
    Personnel returnvar;
    return returnvar;
}

/**
 * Set the Personnel object
 */
void setPersonnel(Personnel personnel){
    return;
}
