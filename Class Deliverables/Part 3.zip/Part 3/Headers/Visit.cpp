/**
 * Visit.cpp
 * 
 * Declaration of Visit
 */

#include "Visit.h"

using namespace std;


/**
 * @brief Get the Date Time object
 */
DateTime getDateTime(){
    DateTime returnvar;
    return returnvar;
}

/**
 * @brief Get the Patient object
 */
Patient getPatient(){
    Patient returnvar;
    return returnvar;
}

/**
 * @brief Get the Type object
 */
string getType(){
    string returnvar;
    return returnvar;
}

/**
 * @brief Get the Personnel object
 */
Personnel getPersonnel(){
    Personnel returnvar;
    return returnvar;
}

/**
 * @brief Get the Test object
 */
Test getTest(){
    Test returnvar;
    return returnvar;
}

/**
 * @brief Get the Test Results object
 */
TestResult* getTestResults(){
    TestResult* returnvar;
    return returnvar;
}


/**
 * @brief Set the Patient object
 */
void setPatient(Patient patient){
    return;
}

/**
 * @brief Set the Type object
 */
void setType(string type){
    return;
}

/**
 * @brief Set the Personnel object
 */
void setPersonnel(Personnel personnel){
    return;
}

/**
 * @brief Set the Date Time object
 */
void setDateTime(DateTime dateTime){
    return;
}

/**
 * @brief Add a test to the appointment
 */
void addTest(Test test){
    return;
}

/**
 * @brief Remove a test from the appointment
 */
void removeTest(Test test){
    return;
}

/**
 * @brief Record a test result for the appointment
 */
void addTestResult(TestResult testResult){
    return;
}

/**
 * @brief Remove a testresult from the appointment
 */
void removeTestResult(TestResult testResult){
    return;
}