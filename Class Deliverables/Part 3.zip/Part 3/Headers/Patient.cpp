/**
 * Patient.cpp
 * 
 * Declaration of the PatientClass
 */

#include "Patient.h"

using namespace std;

/**
 * Return the patient's name
 */
string getName(){
    string name;
    return name;
}

/**
 * Return the patient's gender
 */
string getGender(){
    string gender;
    return gender;
}

/**
 * Return the patient's race
 */
string getRace(){
    string race;
    return race;
}

/**
 * Return the patient's type
 */
string getPatientType(){
    string patientType;
    return patientType;
}

/**
 * Return the patient's date of birth
 */
Date getDob(){
    Date dob;
    return dob;
}

/**
 * Return the patient's KSU ID
 */
int getKSUID(){
    int ksuID;
    return ksuID;
}

/**
 * Set the patient's type
 */
void setPatientType(string patienttype){
    return;
}

/**
 * Set the patient's name
 */
void setName(string name){
    return;
}

/**
 * Set the patient's gender
 */
void setGender(string gender){
    return;
}

/**
 * Set the patient's race
 */
void setRace(string race){
    return;
}

/**
 * Set the patient's date of birth
 */
void setDob(Date dob){
    return;
}

/**
 * Set the patient's KSU ID
 */
void setKSUID(int ksuID){
    return;
}
