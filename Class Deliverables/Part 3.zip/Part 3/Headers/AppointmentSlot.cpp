/**
 * AppointmentSlot.cpp
 * 
 * Declaration of AppointmentSlot
 */

#include "AppointmentSlot.h"

using namespace std;

/**
 * Return the starting time of the slot
 */
DateTime getStartTime(){
    DateTime returnVar;

    return returnVar;
}

/**
 * Return the ending time of the slot
 */
DateTime getEndTime(){
    DateTime returnVar;
    
    return returnVar;
}

/**
 * Set the starting time of the slot
 */
void setStartTime(DateTime startTime){
    return;
}

/**
 * Set the ending time of the slot
 */
void setEndTime(DateTime endTime){
    return;
}