/**
 * Schedule.cpp
 * 
 * Declaration of Schedule
 */


#include "Schedule.h"

using namespace std;

/**
 * Return the date of the schedule
 */
Date getDate(){
    Date returnVar;
    return returnVar;
}

/**
 * Return the booked appointments for that date
 */
Appointment* getAppointments(){
    Appointment* bookedAppointments;
    return bookedAppointments;
}

/**
 * Return the available appointment slots for that date
 */
AppointmentSlot* getAvailableSlots(){
    AppointmentSlot* availableSlots;
    return availableSlots;
}

/**
 * Set the date for the schedule
 */
void setDate(Date date){
    return;
}

/**
 * Add an appointment to the booked appointments
 */
void addAppointment(Appointment appointment){
    return;
}

/**
 * Remove an appointment to the booked appointments
 */
void removeAppointment(Appointment appointment){
    return;
}

/**
 * Add an Appointment Slot to the available Appointment Slots
 */
void addAvailableSlot(AppointmentSlot slot){
    return;
}

/**
 * Remove an Appointment Slot to the available Appointment Slots
 */
void removeAvailableSlot(AppointmentSlot slot){
    return;
}
