/**
 * Appointment.cpp
 * 
 * Declaration of Appointment
 */

#include "Appointment.h"

using namespace std;

/**
 * Get the Date Time object
 */
DateTime getDateTime(){
    DateTime returnvar;
    return returnvar;
}

/**
 * Get the Patient object
 */
Patient getPatient(){
    Patient returnvar;
    return returnvar;
}

/**
 * Get the Type object
 */
string getType(){
    string returnvar;
    return returnvar;
}

/**
 * Get the Personnel object
 */
Personnel getPersonnel(){
    Personnel returnvar;
    return returnvar;
}

/**
 * Set the Patient object
 */
void setPatient(Patient patient){
    return;
}

/**
 * Set the Type object
 */
void setType(string type){
    return;
}

/**
 * Set the Personnel object
 */
void setPersonnel(Personnel personnel){
    return;
}

/**
 * Set the Date Time object
 */
void setDateTime(DateTime dateTime){
    return;
}