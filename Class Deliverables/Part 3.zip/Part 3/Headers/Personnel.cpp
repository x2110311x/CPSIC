/**
 * Personnel.cpp
 * 
 * Declaration of Personnel
 */

#include "Personnel.h"

using namespace std;

/**
 * Return the name of personnel
 */
string getName(){
    string name;
    return name;
}

/**
 * Return the type of personnel
 */
string getType(){
    string type;
    return type;
}

/**
 * Return the id of personnel
 */
int getID(){
    int id;
    return id;
}

/**
 * Return the working times of personnel
 */
AppointmentSlot* getWorkingTimes(){
    AppointmentSlot* workingTimes;
    return workingTimes;
}

/**
 * Set the type of the personnel
 */
void setType(string type){
    return;
}

/**
 * Set the name of the personnel
 */
void setName(string name){
    return;
}

/**
 * Set the id of the personnel
 */
void setID(int id){
    return;
}

/**
 * Add a working time for the personnel
 */
void addWorkingTime(AppointmentSlot workTime){
    return;
}

/**
 * Remove a working time for the personnel
 */
void removeWorkingTime(AppointmentSlot workTime){
    return;
}