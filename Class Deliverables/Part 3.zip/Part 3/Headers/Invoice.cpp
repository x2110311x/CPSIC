/**
 * Invoice.cpp
 * 
 * Declaration of Invoice
 */


#include "Invoice.h"

using namespace std;

/**
 * Retrieve the visit that corresponds with the invoice
 */
Visit getVisit(){
    Visit returnvar;
    return returnvar;
}

/**
 * Retrieve the cost of the invoice
 */
int getCost(){
    int cost;
    return cost;
}

/**
 * Retrieve the time the invoice was created
 */
DateTime getDateCreated(){
    DateTime dateCreated;
    return dateCreated;
}

/**
 * Retrieve if the invoice is paid
 */
bool isPaid(){
    bool paid;
    return paid;
}

/**
 * Set the visit of the invoice
 */
void setVist(Visit visit){
    return;
}

/**
 * Set the cost of the invoice
 */
void setCost(int cost){
    return;
}

/**
 * Set the date the invoice was created
 */
void setDateCreated(DateTime dateCreated){
    return;
}

/**
 *  pay the invoice
 */
void pay(Payment& payment){
    return;
}