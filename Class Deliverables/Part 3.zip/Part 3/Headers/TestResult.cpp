/**
 * TestResult.cpp
 * 
 * Declaration of TestResult
 */

#include "TestResult.h"

using namespace std;

/**
 * Get the Test object
 */
Test getTest(){
    Test returnvar;
    return returnvar;
}

/**
 * Get the Time Received object
 */
DateTime getTimeReceived(){
    DateTime returnvar;
    return returnvar;
}

/**
 * Get the Result object
 */
string getResult(){
    string returnvar;
    return returnvar;
}

/**
 * Set the Test object
 */
void setTest(Test test){
    return;
}

/**
 * Set the Time Received object
 */
void setTimeReceived(DateTime time){
    return;
}

/**
 * Set the Result object
 */
void setResult( string result){
    return;
}