/**
 * Payment.cpp
 * 
 * Declaration of Payment
 */

#include "Payment.h"

using namespace std;

/** Retrieve the type of payment
*/
string getType(){
    string returnvar;
    return returnvar;
}

/** Retrieve the amount of the payment
*/
int getAmount(){
    int returnvar;
    return returnvar;
}

/** Retrieve the date the payment was received
*/
DateTime getDateReceived(){
    DateTime returnvar;
    return returnvar;
}

/** Retrieve the invoice that corresponds with the payment
*/
Invoice getInvoice(){
    Invoice returnvar;
    return returnvar;
}