/**
 * Test.cpp
 * 
 * Declaration of Test
 */

#include "Test.h"

using namespace std;

/**
 * Get the Time Performed object
 */
DateTime getTimePerformed(){
    DateTime returnvar;
    return returnvar;
}

/**
 * Get the Patient object
 */
Patient getPatient(){
    Patient returnvar;
    return returnvar;
}

/**
 * Get the Type object
 */
string getType(){
    string returnvar;
    return returnvar;
}

/**
* Set the Time Performed object
*/
void setTimePerformed(DateTime time){
    return;
}

/**
 * Set the Patient object
 */
void setPatient(Patient patient){
    return;
}

/**
 * Set the Type object
 */
void setType(string type){
    return;
}