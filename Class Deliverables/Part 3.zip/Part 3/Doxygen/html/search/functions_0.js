var searchData=
[
  ['addappointment_114',['addAppointment',['../class_schedule.html#a8406c2157c04cfdc6b6946ab0a2ab6cb',1,'Schedule']]],
  ['addavailableslot_115',['addAvailableSlot',['../class_schedule.html#a91f472317535422af1fa0e8304e4ca1b',1,'Schedule']]],
  ['addtest_116',['addTest',['../class_visit.html#a327c69bf82cf64f18a3489ebe0741a69',1,'Visit']]],
  ['addtestresult_117',['addTestResult',['../class_visit.html#a54c95b60527d83f2726b58d048139ee9',1,'Visit']]],
  ['addworkingtime_118',['addWorkingTime',['../class_personnel.html#a6e1c9dcfd49f56b6f0bde128ec2e0725',1,'Personnel']]],
  ['appointment_119',['Appointment',['../class_appointment.html#a6f5ebbe07e02feaab6600c0f6297e694',1,'Appointment::Appointment()'],['../class_appointment.html#a92af6a78192dae4a630d3a2d462492a9',1,'Appointment::Appointment(string type, Patient patient, Personnel personnel, AppointmentSlot dateTime)']]]
];
