# The Coronavirus Pandemic System Integrated Control

## Index
### Deliverable 1,6
Located in the headers folder

### Deliverables 2,3,4,5
Located in the UML folder
The class diagrams we submitted from part 2 had inheritance structure and the operations included, as well as annotations on the relationships

### Deliverable 7
This file

### Deliverable 8
Located in the Doxygen folder

## Member Statements
### Scott Caldwell
My overall experience has been very positive. My team members have been very knowledgeable and fair. It has been a large learning experience for me especially considering the new conditions we have been under, but I’m very happy with the perseverance of our group and with the product we have so far.

### Adam Adkins
My experience so far in this group has been very positive. Communication and expectations have been clear throughout. I have also learned many new skills involved in a team-oriented Software Design process from using a SCRUM board to analyzing problems as a team to create objects. The team as a whole has been very adaptable and respectful which has helped the flow of our progress.

### Alex Sweeney

My experience with this project has been very positive. It's definitely a different and challenging project, with everything being remote, but it also sheds light on a possible real world experience. Sometimes you are a remote developer, or have remote teams, and this gives valuable experience towards that. Ultimately having the ability to break down something and build it as a team has been a great experience so far.

